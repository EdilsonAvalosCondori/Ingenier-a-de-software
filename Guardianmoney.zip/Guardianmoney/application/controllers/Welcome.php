<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model(array('Consultas', 'Salario_model'));
    }

    public function index() {
        $this->load->view('welcome_message');
    }

    public function diego() {
        echo "hola Katia";
        $a = 3;
        $b = 10;
        $c = $a + $b;
        echo "$a + $b = $c";
    }

    public function verificaingreso() {
        $username = $this->input->post("user");
        $password = $this->input->post("pass");
        $resultado = $this->Consultas->login($username, $password);
        if ($resultado) {
            $this->session->set_userdata('username', $username);
            $this->session->set_userdata('user_id', $resultado->id); 
            $this->session->set_userdata('logged_in', TRUE);

            redirect('welcome/panel');
        } else {
            $this->session->set_flashdata('error', 'Usuario o contraseña incorrectos');
            redirect('welcome/index');
        }
    }

    public function panel() {
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
        $this->load->view('panel1');
    }

    public function logout() {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect('welcome/index');
    }

    public function show_register() {
        $this->load->view('register');
    }

    public function register() {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('register');
        } else {
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            if ($this->Consultas->register($username, $password)) {
                $usuario_id = $this->db->insert_id();
                $this->session->set_userdata('username', $username);
                $this->session->set_userdata('user_id', $usuario_id);
                $this->session->set_userdata('logged_in', TRUE);
                redirect('welcome/panel');
            } else {
                echo "Failed to register user";
            }
        }
    }
}

