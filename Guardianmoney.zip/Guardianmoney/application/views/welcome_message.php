<!DOCTYPE html>
<html lang="es" data-bs-theme="auto">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Iniciar Sesión | GuardianMoney</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/styles.css'); ?>">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body class="d-flex align-items-center py-4 bg-body-tertiary">

<main class="login-container">
    <div class="login-box">
        <img src="<?php echo base_url('assets/images/guardianmoney-logo.png'); ?>" alt="GuardianMoney Logo" class="brand-logo">
        <h1 class="h3 mb-3 fw-normal brand-title">GuardianMoney</h1>
        <h1 class="h5 mb-3 fw-normal">Gestiona tus finanzas personales y familiares</h1>
        
        <!-- Mostrar mensaje de error -->
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>

        <?php echo form_open("welcome/verificaingreso"); ?>

        <div class="form-group">
            <i class="fas fa-envelope"></i>
            <input type="email" class="form-control" id="user" name="user" placeholder="Correo Electrónico" required>
        </div>
        <div class="form-group">
            <i class="fas fa-lock"></i>
            <input type="password" class="form-control" id="pass" name="pass" placeholder="Contraseña" required>
        </div>

        <div class="form-check text-start mb-3">
            <input class="form-check-input" type="checkbox" value="remember-me" id="rememberMe">
            <label class="form-check-label" for="rememberMe">
                Recordarme
            </label>
        </div>
        <button class="btn btn-primary w-100 py-2" type="submit">Iniciar Sesión</button>
        <p class="mt-5 mb-3 text-body-secondary">&copy; 2017–2024 GuardianMoney</p>
        <?php echo form_close(); ?>

        <!-- Enlace al formulario de registro -->
        <p class="text-center">
            <a href="<?php echo site_url('welcome/show_register'); ?>" class="forgot-password">Crear una cuenta</a>
        </p>
    </div>
</main>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
