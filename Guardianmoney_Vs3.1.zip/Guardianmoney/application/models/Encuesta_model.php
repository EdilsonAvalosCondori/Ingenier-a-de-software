<?php
class Encuesta_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }

    public function guardar_encuesta($data) {
        return $this->db->insert('encuestas_satisfaccion', $data);
    }

    public function obtener_encuestas() {
        $query = $this->db->get('encuestas_satisfaccion');
        return $query->result();
    }
}
?>




