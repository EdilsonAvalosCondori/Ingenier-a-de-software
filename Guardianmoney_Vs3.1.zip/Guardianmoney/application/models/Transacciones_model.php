<?php
class Transacciones_model extends CI_Model {

    public function __construct(){
        $this->load->database();
    }

    public function insertar_transaccion($data) {
        return $this->db->insert('transacciones', $data);
    }

    public function obtener_ingresos($user_id) {
        $this->db->where('usuario_id', $user_id);
        $this->db->where('tipo', 'ingreso');
        $query = $this->db->get('transacciones');
        return $query->result();
    }

    public function obtener_gastos($user_id) {
        $this->db->where('usuario_id', $user_id);
        $this->db->where('tipo !=', 'ingreso');
        $query = $this->db->get('transacciones');
        return $query->result();
    }

    public function obtener_gastos_usuario($user_id) {
        $this->db->where('usuario_id', $user_id);
        $query = $this->db->get('transacciones');
        return $query->result();
    }

    public function obtener_transacciones($user_id) {
        $this->db->where('usuario_id', $user_id);
        $query = $this->db->get('transacciones');
        return $query->result();
    }
}
?>





