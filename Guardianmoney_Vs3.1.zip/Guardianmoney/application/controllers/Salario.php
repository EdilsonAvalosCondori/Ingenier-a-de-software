<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Salario extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Salario_model');
        $this->load->model('Transacciones_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
    }

    public function index(){
        $this->load->view('salario/panel');
    }

    public function ingresar(){
        $this->form_validation->set_rules('salario', 'Salario', 'required|numeric');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('salario/ingresar');
        } else {
            $data = array(
                'usuario_id' => $this->session->userdata('user_id'),
                'salario' => $this->input->post('salario'),
                'fecha' => date('Y-m-d H:i:s')
            );
            $this->Salario_model->insertar_salario($data);
            $this->session->set_flashdata('success', 'Salario ingresado correctamente');
            redirect('salario');
        }
    }

    public function presupuesto(){
        $this->form_validation->set_rules('categoria', 'Categoría', 'required');
        $this->form_validation->set_rules('monto', 'Monto', 'required|numeric');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('salario/presupuesto');
        } else {
            $data = array(
                'usuario_id' => $this->session->userdata('user_id'),
                'categoria' => $this->input->post('categoria'),
                'monto' => $this->input->post('monto'),
                'fecha' => date('Y-m-d H:i:s')
            );
            $this->Salario_model->insertar_presupuesto($data);
            $this->session->set_flashdata('success', 'Presupuesto ingresado correctamente');
            redirect('salario');
        }
    }

    public function ahorros(){
        $this->form_validation->set_rules('monto', 'Monto', 'required|numeric');
        
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('salario/ahorros');
        } else {
            $data = array(
                'usuario_id' => $this->session->userdata('user_id'),
                'monto' => $this->input->post('monto'),
                'fecha' => date('Y-m-d H:i:s')
            );
            $this->Salario_model->insertar_ahorros($data);
            $this->session->set_flashdata('success', 'Ahorros ingresados correctamente');
            redirect('salario');
        }
    }

    public function revision(){
        $user_id = $this->session->userdata('user_id');
        $data['salarios'] = $this->Salario_model->obtener_salarios($user_id);
        $data['presupuestos'] = $this->Salario_model->obtener_presupuestos($user_id);
        $data['ahorros'] = $this->Salario_model->obtener_ahorros($user_id);
        $this->load->view('salario/revision', $data);
    }

    public function panel(){
        $this->load->view('salario/panel');
    }

    public function estado_actual_ingreso() {
        $user_id = $this->session->userdata('user_id');

        $ingresos = $this->Salario_model->obtener_salarios($user_id);
        $presupuestos = $this->Salario_model->obtener_presupuestos($user_id);
        $ahorros = $this->Salario_model->obtener_ahorros($user_id);
        $gastos = $this->Transacciones_model->obtener_gastos_usuario($user_id);

        $total_ingresos = 0;
        foreach ($ingresos as $ingreso) {
            $total_ingresos += $ingreso->salario;
        }

        $total_presupuestos = 0;
        foreach ($presupuestos as $presupuesto) {
            $total_presupuestos += $presupuesto->monto;
        }

        $total_ahorros = 0;
        foreach ($ahorros as $ahorro) {
            $total_ahorros += $ahorro->monto;
        }

        $total_gastos = 0;
        foreach ($gastos as $gasto) {
            $total_gastos += $gasto->monto;
        }

        $estado_actual = $total_ingresos - $total_presupuestos - $total_ahorros - $total_gastos;

        $data['estado_actual'] = $estado_actual;
        $data['ingresos'] = $ingresos;
        $data['presupuestos'] = $presupuestos;
        $data['ahorros'] = $ahorros;
        $data['gastos'] = $gastos;
        $data['total_ingresos'] = $total_ingresos;
        $data['total_presupuestos'] = $total_presupuestos;
        $data['total_ahorros'] = $total_ahorros;
        $data['total_gastos'] = $total_gastos;

        $this->load->view('salario/estado_actual_ingreso', $data);
    }
}
?>


















