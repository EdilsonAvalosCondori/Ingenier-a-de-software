<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Encuesta extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Encuesta_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
    }

    public function index() {
        $this->load->view('encuesta/nueva_encuesta');
    }

    public function guardar() {
        $this->form_validation->set_rules('facilidad_uso', 'Facilidad de uso', 'required|numeric');
        $this->form_validation->set_rules('precision_datos', 'Precision de datos', 'required|numeric');
        $this->form_validation->set_rules('satisfaccion_general', 'Satisfaccion general', 'required|numeric');
        $this->form_validation->set_rules('comentarios', 'Comentarios', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('encuesta/nueva_encuesta');
        } else {
            $data = array(
                'usuario_id' => $this->session->userdata('user_id'),
                'facilidad_uso' => $this->input->post('facilidad_uso'),
                'precision_datos' => $this->input->post('precision_datos'),
                'satisfaccion_general' => $this->input->post('satisfaccion_general'),
                'comentarios' => $this->input->post('comentarios'),
                'fecha' => date('Y-m-d H:i:s')
            );
            $this->Encuesta_model->guardar_encuesta($data);
            $this->session->set_flashdata('success', 'Encuesta guardada correctamente');
            redirect('encuesta');
        }
    }

    public function mostrar_encuestas() {
        $data['encuestas'] = $this->Encuesta_model->obtener_encuestas();
        $this->load->view('encuesta/mostrar_encuestas', $data);
    }
}
?>





