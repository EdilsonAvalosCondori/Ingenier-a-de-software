<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado Actual de Ingreso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background-image: url('<?php echo base_url('assets/images/dark.jpg'); ?>');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            padding: 20px;
        }
        .container {
            background: rgba(255, 255, 255, 0.85);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 1400px;
        }
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        .details {
            text-align: center;
        }
        .details ul {
            list-style: none;
            padding: 0;
        }
        .details ul li {
            margin: 10px 0;
        }
        .table-container {
            margin-top: 20px;
        }
        @media (max-width: 768px) {
            .row > div {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Estado Actual de Ingreso</h1>
            <h2><?php echo $estado_actual; ?></h2>
        </div>
        <div class="details">
            <h3>Detalles</h3>
            <ul>
                <li>Total Ingresos: <?php echo $total_ingresos; ?></li>
                <li>Total Presupuestos: <?php echo $total_presupuestos; ?></li>
                <li>Total Ahorros: <?php echo $total_ahorros; ?></li>
                <li>Total Gastos: <?php echo $total_gastos; ?></li>
            </ul>
        </div>

        <div class="row">
            <div class="col-md-6 table-container">
                <h3>Ingresos</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Salario</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ingresos as $ingreso) : ?>
                            <tr>
                                <td><?php echo $ingreso->id; ?></td>
                                <td><?php echo $ingreso->salario; ?></td>
                                <td><?php echo $ingreso->fecha; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-6 table-container">
                <h3>Ahorros</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Monto</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ahorros as $ahorro) : ?>
                            <tr>
                                <td><?php echo $ahorro->id; ?></td>
                                <td><?php echo $ahorro->monto; ?></td>
                                <td><?php echo $ahorro->fecha; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 table-container">
                <h3>Presupuestos</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Categoría</th>
                            <th>Monto</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($presupuestos as $presupuesto) : ?>
                            <tr>
                                <td><?php echo $presupuesto->id; ?></td>
                                <td><?php echo $presupuesto->categoria; ?></td>
                                <td><?php echo $presupuesto->monto; ?></td>
                                <td><?php echo $presupuesto->fecha; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="col-md-6 table-container">
                <h3>Gastos</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Monto</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($gastos as $gasto) : ?>
                            <tr>
                                <td><?php echo $gasto->id; ?></td>
                                <td><?php echo $gasto->monto; ?></td>
                                <td><?php echo $gasto->fecha; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>








