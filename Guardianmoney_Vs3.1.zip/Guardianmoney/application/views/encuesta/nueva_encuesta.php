<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Encuesta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background: url('<?php echo base_url('assets/images/dark.jpg'); ?>') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: rgba(255, 255, 255, 0.85);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 600px;
        }

        h1 {
            color: #333;
            font-size: 2em;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-label {
            color: #555;
            font-weight: bold;
        }

        .btn-primary {
            background-color: #4CAF50;
            border: none;
            font-size: 1em;
            padding: 10px 20px;
            border-radius: 5px;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #45a049;
        }

        .mb-3 {
            margin-bottom: 20px;
        }

        .form-control:focus {
            border-color: #4CAF50;
            box-shadow: 0 0 0 0.2rem rgba(76, 175, 80, 0.25);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Encuesta de Satisfacción</h1>
        <?php echo validation_errors(); ?>
        <?php echo form_open('encuesta/guardar'); ?>
            <div class="mb-3">
                <label for="facilidad_uso" class="form-label">Facilidad de uso (1-5)</label>
                <input type="number" class="form-control" id="facilidad_uso" name="facilidad_uso" min="1" max="5" required>
            </div>
            <div class="mb-3">
                <label for="precision_datos" class="form-label">Precisión de datos (1-5)</label>
                <input type="number" class="form-control" id="precision_datos" name="precision_datos" min="1" max="5" required>
            </div>
            <div class="mb-3">
                <label for="satisfaccion_general" class="form-label">Satisfacción general (1-5)</label>
                <input type="number" class="form-control" id="satisfaccion_general" name="satisfaccion_general" min="1" max="5" required>
            </div>
            <div class="mb-3">
                <label for="comentarios" class="form-label">Comentarios</label>
                <textarea class="form-control" id="comentarios" name="comentarios" rows="4" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar Encuesta</button>
        <?php echo form_close(); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


