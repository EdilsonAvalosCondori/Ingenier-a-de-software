<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de Encuestas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Resultados de Encuestas de Satisfaccion</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Facilidad de Uso</th>
                    <th>Precision de Datos</th>
                    <th>Satisfaccion General</th>
                    <th>Comentarios</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($encuestas as $encuesta): ?>
                    <tr>
                        <td><?php echo $encuesta->id; ?></td>
                        <td><?php echo $encuesta->facilidad_uso; ?></td>
                        <td><?php echo $encuesta->precision_datos; ?></td>
                        <td><?php echo $encuesta->satisfaccion_general; ?></td>
                        <td><?php echo $encuesta->comentarios; ?></td>
                        <td><?php echo $encuesta->fecha; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

