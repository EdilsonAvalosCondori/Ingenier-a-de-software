<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Últimos Movimientos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
            background-image: url('<?php echo base_url('assets/images/dark.jpg'); ?>');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.85);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            margin-top: 30px;
        }
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        .table-container {
            border: 1px solid #ddd;
            border-radius: 0 0 10px 10px;
            padding: 15px;
            background-color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Últimos Movimientos</h1>
        </div>
        <div class="table-container">
            <h3>Movimientos</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo</th>
                        <th>Monto</th>
                        <th>Fecha</th>
                        <th>Pagado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($movimientos as $movimiento) : ?>
                        <tr>
                            <td><?php echo $movimiento->id; ?></td>
                            <td><?php echo urldecode($movimiento->tipo); ?></td>
                            <td><?php echo $movimiento->monto; ?></td>
                            <td><?php echo $movimiento->fecha; ?></td>
                            <td><?php echo $movimiento->pagado ? 'Sí' : 'No'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





